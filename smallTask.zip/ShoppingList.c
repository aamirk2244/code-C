#define _CRT_SECURE_NO_WARNINGS
#include"ShoppingList.h"
#include<stdio.h>
#include<stdlib.h> // For malloc() and free()


void addItem(struct ShoppingList *list)
{



	list->itemList = (struct GrocaryItem *) realloc(list->itemList, (list->length+1)*sizeof(struct GrocaryItem));


	printf("Enter name: ");
	scanf("%s", list->itemList[list->length].productName);
	printf("Enter amount: ");
	scanf("%f", &list->itemList[list->length].amount);
	printf("Enter unit: ");
	scanf("%s", list->itemList[list->length].unit);

	while(list->itemList[list->length].amount <= 0)
	{
		printf("Error! The amount %4.2f is invalid. Please enter a positive value: ", list->itemList[list->length].amount);
		scanf("%f", &list->itemList[list->length].amount);
	}
	list->length++;
	return;
}

void printList(struct ShoppingList *list)
{
	int i;

	if(list->length == 0)
	{
		printf("the list is empty\n");
	}
	else
	{
		printf("\nYour list contains %d items:\n\n", list->length);
		for(i=0; i<list->length; i++)
		{
			printf("%d. %-10s\t%4.2f\t%s\n", (i+1), 
									   list->itemList[i].productName,
									   list->itemList[i].amount,
									   list->itemList[i].unit);
		}
	}

	return;


}

void editItem(struct ShoppingList *list)
{
	int item_no;
	printf("Which item do you want to change? ");
	scanf("%d", &item_no);

	if(item_no > list->length)
	{
		printf("The list contains only %d items!\n", list->length);
	}
	else
	{
		printf("Current amount: %4.2f %s\n", list->itemList[item_no-1].amount,
										  list->itemList[item_no-1].unit);
		printf("Enter new amount: ");
		scanf("%f", &list->itemList[item_no-1].amount);
	}

	return;
}

void removeItem(struct ShoppingList *list)
{
	int item_no;
	int i;

	if (list->length == 0)
	{
		printf("Error! There is nothing in the list!\n");
		return;
	}

	printf("Which item do you want to remove? ");
	scanf("%d", &item_no);

	while(item_no > list->length)
	{
		printf("Error! The list contains only %d items!\n", list->length);
		printf("Which item do you want to remove? ");
		scanf("%d", &item_no);
	}

	for(i=item_no-1; i<list->length-1; i++)
	{
		list->itemList[i] = list->itemList[i+1];
	}

	list->length--;


	return;
}

void saveList(struct ShoppingList *list)
{
	char filename[20];
	int i = 0;
	FILE *fptr;
	printf("Please enter a filename: ");
	scanf("%s", filename);


	fptr = fopen(filename, "w");

	if(fptr == NULL)
	{
		printf("Error! File cannot be opened.\n");
		return;
	}
	fprintf(fptr, "%d\n", list->length);
	for(i=0; i<list->length; i++)
	{
		fprintf(fptr, "%s %f %s\n", list->itemList[i].productName,
								  list->itemList[i].amount,
								  list->itemList[i].unit);
	}
	fclose(fptr);

}

void loadList(struct ShoppingList* list)
{
	char filename[20];
	int i = 0;

	int elem_count = 0;
	FILE *fptr;
	printf("Please enter a filename: ");
	scanf("%s", filename);


	printf("File to be loaded: %s\n", filename);
	fptr = fopen(filename, "r");

	if(fptr == NULL)
	{
		printf("Error! File cannot be opened.\n");
		return;
	}

	fscanf(fptr, "%d", &elem_count);



	free(list->itemList);


	list->itemList = (struct GrocaryItem *) malloc(elem_count*sizeof(struct GrocaryItem));

	list->length = elem_count;

	for(i=0; i<elem_count; i++)
	{

		fscanf(fptr, "%s %f %s\n", list->itemList[i].productName,
								  &list->itemList[i].amount,
								  list->itemList[i].unit);

	}
	fclose(fptr);
}
