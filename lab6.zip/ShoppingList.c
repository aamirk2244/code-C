#define _CRT_SECURE_NO_WARNINGS
#include "ShoppingList.h"
#include<stdio.h>
#include<string.h>
#include<stdlib.h> // For malloc() and free()


void addItem(struct ShoppingList *list)
{
    if (list->length >= 5)return;
    float amount;
    printf("Enter Name : ");
    scanf(" %[^\n]s", list->itemList[list->length].productName);
    while(1)
    {
        printf("Enter Amount : ");
        scanf(" %f", &amount);
        if(amount <= 0)
        {
            printf("Invalid Amount\n");
        }
        else break;
        
    }

    list->itemList[list->length].amount = amount;
    printf("Enter Unit : ");
    scanf(" %[^\n]s", list->itemList[list->length].unit);

    printf("\n %s was added to the shopping list ", list->itemList[list->length].productName);

    list->length += 1;

    
}

void printList(struct ShoppingList *list)
{
    if(list->length == 0)
    {
        printf("The list is empty\n");
        return;
    }
    printf("Your list contain %d items\n", list->length);
    for(int i= 0 ; i < list->length; i++)
    {
        printf("%s \t %f \t %s \n", list->itemList[i].productName, list->itemList[i].amount, list->itemList[i].unit);
    }


}

void editItem(struct ShoppingList *list)
{
    int index;

    if(list->length == 0)
    {
        printf("The list is empty\n");
        return;
    }
    printList(list);
    
     while(1)
    {
        printf("Enter index Of The Element edit : Note that ist element start from 0 \n");
        scanf("%d", &index);
        if(index >= list->length || index < 0)
        {
            printf("Invalid Index number\n");
        }
        else break;                    // if index number to remove the array element is correct 
        
    }
    printf("Item %s is selected to edit  ", list->itemList[index].productName);
    float amount;
    printf("Enter Name : ");
    scanf(" %[^\n]s", list->itemList[index].productName);
    while(1)
    {
        printf("Enter Amount : ");
        scanf(" %f", &amount);
        if(amount <= 0)
        {
            printf("Invalid Amount\n");
        }
        else break;
        
    }

    list->itemList[index].amount = amount;
    printf("Enter Unit : ");
    scanf(" %[^\n]s", list->itemList[index].unit);
    printf("Item is Edited Successfully \n");


}

void removeItem(struct ShoppingList *list)          // index will start from zero..
{
    if(list->length == 0)
    {
        printf("The list is empty\n");
        return;
    }

    int index;
    printList(list);             // printing elements
    
     while(1)
    {
        printf("Enter index Of The Element to remove \n");
        scanf("%d", &index);
        if(index >= list->length || index < 0)
        {
            printf("Invalid Index number\n");
        }
        else break;                    // if index number to remove the array element is correct 
        
    }
    printf("%s is removed from the Shopping list \n", list->itemList[index].productName);

     for(int i = index; i < list->length; i++)
     {
         if(i + 1 < list->length)                        // moving all element to the right
         {
            list->itemList[i].amount = list->itemList[i+1].amount;
            strcpy(list->itemList[i].productName , list->itemList[i+1].productName);       // copy content from one to other
         
            strcpy(list->itemList[i].unit , list->itemList[i+1].unit);   
         }
         

     }

    list->length -= 1;      // decrement length


}

void saveList(struct ShoppingList *list)
{


}

void loadList(struct ShoppingList* list)
{
	
}
